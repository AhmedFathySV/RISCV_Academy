#include <cstdint>
#include <stddef.h>

// Simple scalar histogram (Baseline)
void compute_histogram_scalar(const uint8_t* image, size_t n, uint32_t* hist) {
    // Clear histogram
    for(int i = 0; i < 256; i++) {
        hist[i] = 0;
    }
    
    // Count pixels
    for (size_t i = 0; i < n; i++) {
        hist[image[i]]++;
    }
}