#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

// Compile-time selectors (can be overridden with -D flags)
#ifndef HIST_METHOD
#define HIST_METHOD 0  // 0 = scalar, 1 = vector
#endif

#ifndef HIST_DATASET
#define HIST_DATASET 0  // 0 = constant, 1 = uniform, 2 = Zipf-like
#endif

// External function declarations
extern void compute_histogram_scalar(const uint8_t*, size_t, uint32_t*);
extern void compute_histogram_vector(const uint8_t*, size_t, uint32_t*);

// Simple timer using cycle counter (if available in your system)
// For gem5, you might need to use mcpat or stats
static inline uint64_t get_cycles(void) {
    uint64_t cycles;
    #if defined(__riscv) && __riscv_xlen == 64
        asm volatile("rdcycle %0" : "=r"(cycles));
    #elif defined(__riscv) && __riscv_xlen == 32
        uint32_t cycles_lo, cycles_hi;
        asm volatile("rdcycle %0" : "=r"(cycles_lo));
        asm volatile("rdcycleh %0" : "=r"(cycles_hi));
        cycles = ((uint64_t)cycles_hi << 32) | cycles_lo;
    #else
        cycles = 0;
    #endif
    return cycles;
}

// Result structure for timing
typedef struct {
    uint64_t cycles;
    uint64_t instructions;  // Optional, if you can count them
} Result;

// Measurement wrapper
Result measure(void (*hist_func)(const uint8_t*, size_t, uint32_t*), 
               const uint8_t* image, size_t n, uint32_t* hist) {
    Result result;
    
    // Warmup: run once to load code into cache
    hist_func(image, n, hist);
    
    // Clear histogram for actual measurement
    for(int i = 0; i < 256; i++) hist[i] = 0;
    
    // Start timing
    uint64_t start_cycles = get_cycles();
    
    // Run the histogram function
    hist_func(image, n, hist);
    
    // Stop timing
    uint64_t end_cycles = get_cycles();
    
    result.cycles = end_cycles - start_cycles;
    result.instructions = 0;  // Set if you have instruction counter
    
    return result;
}

// Dataset generator: Constant (all pixels same value)
void generate_constant_dataset(uint8_t* image, size_t n) {
    uint8_t constant_value = 128;  // All pixels = 128
    for (size_t i = 0; i < n; i++) {
        image[i] = constant_value;
    }
}

// Dataset generator: Uniform (random 0-255)
void generate_uniform_dataset(uint8_t* image, size_t n) {
    // Simple LCG random number generator (fixed seed for reproducibility)
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        image[i] = (uint8_t)((seed >> 16) & 0xFF);
    }
}

// Dataset generator: Zipf-like (skewed distribution)
void generate_zipf_dataset(uint8_t* image, size_t n) {
    // Zipf-like: lower values more frequent
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        // Generate Zipf-like distribution: favor lower values
        uint32_t r = (seed >> 16) & 0xFFFF;
        uint8_t value = (uint8_t)(r % 256);
        // Skew toward lower values
        if ((seed & 0xFF) < 0x80) {  // 50% chance
            value = value / 4;  // Favor 0-63 range
        }
        image[i] = value;
    }
}

// Verify histogram correctness
bool verify_histogram(uint32_t* hist, size_t n, int dataset_type) {
    uint32_t total = 0;
    for (int i = 0; i < 256; i++) {
        total += hist[i];
    }
    
    if (total != n) {
        printf("ERROR: Histogram sum %u != image size %zu\n", total, n);
        return false;
    }
    
    // Additional checks based on dataset type
    if (dataset_type == 0) {  // Constant
        // All pixels should be in one bin (128)
        if (hist[128] != n) {
            printf("ERROR: Constant dataset should have all %zu pixels in bin 128\n", n);
            return false;
        }
    }
    
    printf("Histogram verification PASSED (total pixels: %u)\n", total);
    return true;
}

int main() {
    printf("=== Histogram Benchmark ===\n");
    printf("Method: %s\n", HIST_METHOD == 0 ? "Scalar" : "Vector");
    printf("Dataset: %s\n", 
           HIST_DATASET == 0 ? "Constant" : 
           HIST_DATASET == 1 ? "Uniform" : "Zipf-like");
    
    // Image size (adjust based on your needs)
    const size_t N = 1024;  // 1K pixels
    
    // Allocate image and histogram
    uint8_t image[N];
    uint32_t histogram[256] = {0};
    
    // Generate dataset
    printf("Generating dataset...\n");
    switch (HIST_DATASET) {
        case 0: generate_constant_dataset(image, N); break;
        case 1: generate_uniform_dataset(image, N); break;
        case 2: generate_zipf_dataset(image, N); break;
    }
    
    // Run selected method
    printf("Running %s histogram...\n", HIST_METHOD == 0 ? "scalar" : "vector");
    Result result;
    
    #if HIST_METHOD == 0
        result = measure(compute_histogram_scalar, image, N, histogram);
    #else
        result = measure(compute_histogram_vector, image, N, histogram);
    #endif
    
    // Print results
    printf("\n=== Results ===\n");
    printf("Cycles: %llu\n", (unsigned long long)result.cycles);
    printf("Instructions: %llu\n", (unsigned long long)result.instructions);
    printf("Cycles per pixel: %.2f\n", (double)result.cycles / N);
    
    // Verify correctness
    printf("\n=== Verification ===\n");
    bool correct = verify_histogram(histogram, N, HIST_DATASET);
    
    // Print some histogram statistics
    printf("\n=== Histogram Stats ===\n");
    uint32_t max_count = 0;
    int max_bin = 0;
    for (int i = 0; i < 256; i++) {
        if (histogram[i] > max_count) {
            max_count = histogram[i];
            max_bin = i;
        }
    }
    printf("Most frequent bin: %d (count: %u)\n", max_bin, max_count);
    
    // Print first 16 bins for debugging
    printf("\nFirst 16 bins:\n");
    for (int i = 0; i < 16; i++) {
        printf("Bin %2d: %5u\n", i, histogram[i]);
    }
    
    return correct ? 0 : 1;
}