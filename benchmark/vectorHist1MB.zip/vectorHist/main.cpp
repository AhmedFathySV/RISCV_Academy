#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

// Compile-time selectors (can be overridden with -D flags)
#ifndef HIST_METHOD
#define HIST_METHOD 0  // 0 = scalar, 1 = vector
#endif

#ifndef HIST_DATASET
#define HIST_DATASET 0  // 0 = constant, 1 = uniform, 2 = Zipf-like
#endif

// External function declarations
extern void compute_histogram_scalar(const uint8_t*, size_t, uint32_t*);
extern void compute_histogram_vector(const uint8_t*, size_t, uint32_t*);

// Large arrays declared as static to avoid stack overflow
static uint8_t image[1024 * 1024];
static uint32_t histogram[256];

// Cycle counter
static inline uint64_t get_cycles(void) {
    uint64_t cycles;
#if defined(__riscv) && __riscv_xlen == 64
    asm volatile("rdcycle %0" : "=r"(cycles));
#elif defined(__riscv) && __riscv_xlen == 32
    uint32_t cycles_lo, cycles_hi;
    asm volatile("rdcycle %0" : "=r"(cycles_lo));
    asm volatile("rdcycleh %0" : "=r"(cycles_hi));
    cycles = ((uint64_t)cycles_hi << 32) | cycles_lo;
#else
    cycles = 0;
#endif
    return cycles;
}

// Result structure
typedef struct {
    uint64_t cycles;
    uint64_t instructions;
} Result;

// Measurement function
Result measure(void (*hist_func)(const uint8_t*, size_t, uint32_t*),
               const uint8_t* img, size_t n, uint32_t* hist) {
    Result result;
    
    // Warmup
    hist_func(img, n, hist);
    
    // Clear histogram
    for (int i = 0; i < 256; i++) {
        hist[i] = 0;
    }
    
    // Measure
    uint64_t start_cycles = get_cycles();
    hist_func(img, n, hist);
    uint64_t end_cycles = get_cycles();
    
    result.cycles = end_cycles - start_cycles;
    result.instructions = 0;
    return result;
}

// Dataset generators
void generate_constant_dataset(uint8_t* img, size_t n) {
    for (size_t i = 0; i < n; i++) {
        img[i] = 128;
    }
}

void generate_uniform_dataset(uint8_t* img, size_t n) {
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        img[i] = (uint8_t)((seed >> 16) & 0xFF);
    }
}

void generate_zipf_dataset(uint8_t* img, size_t n) {
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        uint32_t r = (seed >> 16) & 0xFFFF;
        uint8_t value = (uint8_t)(r % 256);
        if ((seed & 0xFF) < 0x80) {
            value = value / 4;
        }
        img[i] = value;
    }
}

// Verification
bool verify_histogram(uint32_t* hist, size_t n, int dataset_type) {
    uint32_t total = 0;
    for (int i = 0; i < 256; i++) {
        total += hist[i];
    }
    
    if (total != n) {
        printf("ERROR: Histogram sum %u != image size %zu\n", total, n);
        return false;
    }
    
    printf("Histogram verification PASSED (total pixels: %u)\n", total);
    return true;
}

// Main function
int main() {
    const size_t N = 1024 * 1024;  // 1MB image
    
    printf("=== Histogram Benchmark (1024x1024) ===\n");
    printf("Method: %s\n", HIST_METHOD == 0 ? "Scalar" : "Vector");
    printf("Dataset: %s\n",
           HIST_DATASET == 0 ? "Constant" :
           HIST_DATASET == 1 ? "Uniform" : "Zipf-like");
    printf("Image Size: %zu pixels (1 MB)\n\n", N);
    
    // Clear histogram
    for (int i = 0; i < 256; i++) {
        histogram[i] = 0;
    }
    
    // Generate dataset
    printf("Generating 1MB dataset...\n");
    switch (HIST_DATASET) {
        case 0:
            generate_constant_dataset(image, N);
            break;
        case 1:
            generate_uniform_dataset(image, N);
            break;
        case 2:
            generate_zipf_dataset(image, N);
            break;
    }
    
    // Run benchmark
    printf("Running %s histogram...\n", HIST_METHOD == 0 ? "scalar" : "vector");
    Result result;
    
#if HIST_METHOD == 0
    result = measure(compute_histogram_scalar, image, N, histogram);
#else
    result = measure(compute_histogram_vector, image, N, histogram);
#endif
    
    // Print results
    printf("\n=== Results ===\n");
    printf("Cycles: %llu\n", (unsigned long long)result.cycles);
    printf("Cycles per pixel: %.4f\n", (double)result.cycles / N);
    
    // Verify
    printf("\n=== Verification ===\n");
    verify_histogram(histogram, N, HIST_DATASET);
    
    return 0;
}