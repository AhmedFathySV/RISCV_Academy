#!/bin/bash
GEM5=/home/me/Documents/gem5/GEM5
OUT=/tmp/hist-multicore

mkdir -p "$OUT"
cp build/histogram/scalar-zipf.elf "$OUT/"

echo "Running 2 Cores with Shared L2 Cache (AtomicSimpleCPU for stability)..."

# Use AtomicSimpleCPU for stable multi-core se.py simulation
# Removed --enable-riscv-vector as we are running the scalar binary
"$GEM5/build/RISCV/gem5.opt" \
    -d "$OUT/dual-core-zipf" \
    "$GEM5/configs/example/se.py" \
    --cpu-type=AtomicSimpleCPU \
    --l2cache \
    -n 2 \
    --cmd="$OUT/scalar-zipf.elf" \
    --cmd="$OUT/scalar-zipf.elf"

echo "Done."
