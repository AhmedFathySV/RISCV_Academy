#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifndef HIST_METHOD
#define HIST_METHOD 0
#endif

#ifndef HIST_DATASET
#define HIST_DATASET 0
#endif

// Declare functions from other files
extern void compute_histogram_scalar(const uint8_t*, size_t, uint32_t*);
extern void compute_histogram_vector(const uint8_t*, size_t, uint32_t*);
extern void compute_histogram_16bins(const uint8_t*, size_t, uint32_t*); // <--- THIS FIXES THE ERROR

// 1,000,000 items as requested by assignment
// Note: Vector version may crash at this size in gem5. 
// If vector crashes, change this to 1024 for vector runs only.
static const size_t N = 1000000; 

static uint8_t image[1000000]; 
static uint32_t histogram[256];

void generate_constant_dataset(uint8_t* img, size_t n) {
    for (size_t i = 0; i < n; i++) img[i] = 128;
}

void generate_uniform_dataset(uint8_t* img, size_t n) {
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        img[i] = (uint8_t)((seed >> 16) & 0xFF);
    }
}

// Strongly skewed dataset (Exercise 2 Requirement)
void generate_zipf_dataset(uint8_t* img, size_t n) {
    uint32_t seed = 42;
    for (size_t i = 0; i < n; i++) {
        seed = seed * 1103515245 + 12345;
        uint32_t r = (seed >> 16) & 0xFFFF;
        
        // 80% of pixels will be between 0-31 (Strongly skewed to dark)
        if ((seed % 100) < 80) {
            img[i] = (uint8_t)(r % 32); 
        } else {
            img[i] = (uint8_t)(r % 256);
        }
    }
}

bool verify_histogram(uint32_t* hist, size_t n, int num_bins) {
    uint32_t total = 0;
    for (int i = 0; i < num_bins; i++) total += hist[i];
    if (total != n) {
        printf("ERROR: Histogram sum %u != image size %zu\n", total, n);
        return false;
    }
    printf("Verification PASSED (Total elements: %zu)\n", total);
    return true;
}

int main() {
    printf("=== Histogram Benchmark (N=%zu) ===\n", N);
    printf("Method: %s\n", HIST_METHOD == 0 ? "Scalar" : "Vector");
    printf("Dataset: %s\n\n", 
           HIST_DATASET == 0 ? "Constant" : 
           HIST_DATASET == 1 ? "Uniform" : "Zipf-like (Skewed)");

    // Clear arrays
    for(int i=0; i<256; i++) histogram[i] = 0;

    // Generate Data
    printf("Generating dataset...\n");
    if (HIST_DATASET == 0) generate_constant_dataset(image, N);
    else if (HIST_DATASET == 1) generate_uniform_dataset(image, N);
    else generate_zipf_dataset(image, N);

    // Run Main Histogram (Scalar or Vector)
    printf("Running main histogram...\n");
    if (HIST_METHOD == 0) compute_histogram_scalar(image, N, histogram);
    else compute_histogram_vector(image, N, histogram);

    verify_histogram(histogram, N, 256);

    // --- EXERCISE 1: 16-BIN TEST ---
    printf("\n=== Exercise 1: 16-Bin Scalar Test ===\n");
    uint32_t hist_16[16];
    
    // Run the 16-bin function
    compute_histogram_16bins(image, N, hist_16);
    
    // Verify sum
    if (verify_histogram(hist_16, N, 16)) {
        printf("Bin 0 (Values 0-15): %u\n", hist_16[0]);
        printf("Bin 15 (Values 240-255): %u\n", hist_16[15]);
        printf("Bin-Index Expression used: index = pixel >> 4\n");
    }

    return 0;
}